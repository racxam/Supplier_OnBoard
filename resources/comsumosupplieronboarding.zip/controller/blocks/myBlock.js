sap.ui.define(["sap/uxap/BlockBase"],function(e){"use strict";return e.extend("com.sumo.supplieronboarding.view.blocks.myBlock",{metadata:{}})});
//# sourceMappingURL=myBlock.js.map